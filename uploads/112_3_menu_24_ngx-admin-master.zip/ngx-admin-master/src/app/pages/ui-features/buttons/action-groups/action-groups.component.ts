import { Component } from '@angular/core';

@Component({
  selector: 'ngx-action-groups',
  styleUrls: ['./action-groups.component.scss'],
  templateUrl: './action-groups.component.html',
})
export class ActionGroupsComponent {
}
