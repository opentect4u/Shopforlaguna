import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-agent',
  templateUrl: './sales-agent.component.html',
  styleUrls: ['./sales-agent.component.css']
})
export class SalesAgentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
