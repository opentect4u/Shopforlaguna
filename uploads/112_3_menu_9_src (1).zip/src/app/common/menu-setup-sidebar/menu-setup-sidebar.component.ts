import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-setup-sidebar',
  templateUrl: './menu-setup-sidebar.component.html',
  styleUrls: ['./menu-setup-sidebar.component.css']
})
export class MenuSetupSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
