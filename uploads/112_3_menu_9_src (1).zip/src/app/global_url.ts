export class global_url_test{
  static URL="http://localhost:3000/"; 
}