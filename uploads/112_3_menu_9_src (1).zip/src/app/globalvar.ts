export class url_set{
    static api_url="http://localhost:3000";
}