import { Component } from '@angular/core';
import { Calendar } from '@fullcalendar/core';
import { CalendarOptions } from '@fullcalendar/angular';
import interactionPlugin from '@fullcalendar/interaction'; // for selectable
import dayGridPlugin from '@fullcalendar/daygrid';
import { Router } from '@angular/router';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myproject';
  constructor(private router:Router) {
    const name = Calendar.name;
  }
  Event=[
    { title: 'event 1', date: '2021-09-10' },
    { title: 'event 2', date: '2021-06-30' }
  ]
  // calendarplugins=[dayGridPlugin];
  calendarOptions: CalendarOptions = {
    initialView: 'dayGridMonth',
    headerToolbar: {
      start: 'prev,next today',
      center: '',
      // end:'month,agendaWeek,agendaDay'
      end: 'dayGridMonth,dayGridWeek,dayGridDay,dayGridlist,addEventButton'
    },
    eventClick:function(arg){
      alert(arg.event.title+ ""+ arg.event.start)

      // alert(arg.event.start)
    },


    navLinks:true,

    editable:true,
    plugins: [ interactionPlugin, dayGridPlugin ],

    dateClick: this.handleDateClick.bind(this), // bind is important!
    events:this.Event,





  };
  handleDateClick(arg:any) {
    console.log('date click! ' +arg.dateStr);

  }
  go_to_mycom(){
        //  window.open('','',"_blank");
        this.router.navigate(['/comp'])
  }
}
