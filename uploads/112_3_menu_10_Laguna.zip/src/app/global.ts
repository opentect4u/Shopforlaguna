export class details{
  public breakfastcoverImage:any=[];
  public breakfastcoverURL:any;
  public breakfastTopImage:any;
  public breakfastTopImageURL:any;
  public breakfastImage:any;
  public breakfastSectionImage:any;
  public breakfastSectionImageURL:any;
  public breakfastMenuImage:any=[];
  public breakfastMenuURL:any;

}
