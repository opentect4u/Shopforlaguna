import { Component, OnInit } from '@angular/core';
import { Calendar, CalendarOptions } from '@fullcalendar/core';

import interactionPlugin from '@fullcalendar/interaction'; // for selectable
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import resourceTimeGridPlugin from '@fullcalendar/resource-timegrid';
import { Router } from '@angular/router';
export interface event{
  title: string;
  start: any;
  end: any;
}
@Component({
  selector: 'app-mycom',
  templateUrl: './mycom.component.html',
  styleUrls: ['../.././assets/css/apps_inner.css',
             '../.././assets/css/apps.css',
             '../.././assets/css/bootstrap.css' ,
            '../.././assets/css/bootstrap.min.css' ,
             '../.././assets/css/font-awesome.css',
             '../.././assets/css/res.css']
})

export class MycomComponent implements OnInit {
  mod:any;
  moddo:any;
  title = 'myproject';
  start_date:any;
  inp:any
  constructor(private router:Router) {
    const name = Calendar.name;
  }
  Event:event[]=[

    { title: 'event 1', start: '2021-09-22',end: '2021-09-30'},
    { title: 'event 2', start: '2021-06-30',end:'2021-07-01' }
  ];
  calendarOptions!: CalendarOptions;

  ngOnInit(): void {
    localStorage.setItem('st','2');
    console.log(localStorage.getItem('St'));
 setInterval(()=>{


  this.calendarOptions= {
    weekends:true,
    eventDurationEditable:true,
    eventStartEditable:true,
    aspectRatio: 3.25,
    initialView: 'dayGridMonth',
    headerToolbar: {
      start: 'prev,next today',
      center: 'title',
      end: 'dayGridMonth,dayGridWeek,dayGridDay'
    },

    eventClick:this.eventclick.bind(this),
    droppable:true,
    selectable: true,
    navLinks:true,
    editable: false,

    nextDayThreshold: '00:00:00',
    plugins: [ interactionPlugin, dayGridPlugin ],

    dateClick: this.handleDateClick.bind(this),

    events:this.Event,
    height:500
};
},500)

}
removeEvents(args:any){
  console.log(args)
}
eventclick (arg:any) {
 console.log(arg);

}


  handleDateClick(arg:any) {

    console.log('date click! ' +arg.start);
     this.start_date=arg.dateStr;
    this.mod=document.getElementById('modalbutton');
     this.mod.click();
     console.log('open modal');
  }
  go_to_mycom(){
    window.open('/comp', '_blank', 'location=yes,height=500,width=400,scrollbars=yes,status=yes'); // Open new window

  }

  toggleWeekends() {
    // this.calendarOptions.weekends = !this.calendarOptions.weekends // toggle the boolean!

  }
  addevent(v1:any,v2:any){
   console.log(v1+" "+v2+ " "+this.start_date,this.Event);



        this.Event[this.Event.length]={
          title:v1,start:this.start_date,end:v2
        }

        console.log(this.Event);
  this.calendarOptions.events=this.Event.concat({
    title:v1,
    start:this.start_date,
    end:v2
  })
  this.inp=document.getElementById('event');
  this.inp.value='';

  this.inp=document.getElementById('date');
  this.inp.value='';



  }
}

