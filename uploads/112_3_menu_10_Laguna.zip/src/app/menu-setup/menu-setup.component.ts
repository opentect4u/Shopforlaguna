import { Component, OnInit } from '@angular/core';
// import { Console } from 'console';
// import { ConsoleReporter } from 'jasmine';

@Component({
  selector: 'app-menu-setup',
  templateUrl: './menu-setup.component.html',
  styleUrls: ['./menu-setup.component.css']
})
export class MenuSetupComponent implements OnInit {
   london:any;
   paris:any;
   Tokyo:any;
   Laguna:any;
   tab1:any=false;
   tab2:any=true;
   tab3:any=true;
   tab4:any=true;
   tab5:any=true;
   t1:any='';
   t2:any='';
   t3:any='';
   t4:any='';
   t5:any='';
   storevalue:any=[]
  constructor() { }

  ngOnInit(): void {
  }
  openCity(e:any){
    if(e=='London'){
       if(this.t1!=''){
        this.tab1=false;
        this.tab2=true;
        this.tab3=true;
        this.tab4=true;
        this.tab5=true;
        this.paris=document.getElementById('London');
            this.paris.className='active';
       }
       else{

       }
    }
    else if(e=='Paris'){
      if(this.t2!=''){
        this.tab1=true;
        this.tab2=false;
        this.tab3=true;
        this.tab4=true;
        this.paris=document.getElementById('Paris');
            this.paris.className='active';
       }
       else{

       }
    }
    else if(e=='Tokyo'){
      if(this.t3!=''){
        this.tab1=true;
        this.tab2=true;
        this.tab3=false;
        this.tab4=true;
        this.paris=document.getElementById('Tokyo');
            this.paris.className='active';
       }
       else{

       }
    }
    else if(e=='Laguna'){
            if(this.t4!=''){
              this.tab1=true;
              this.tab2=true;
              this.tab3=true;
              this.tab4=false;
              this.paris=document.getElementById('Laguna');
                  this.paris.className='active';
             }
             else{

             }
    }
    else if(e=='Shrewsbury'){
      if(this.t5!=''){
        this.tab1=true;
        this.tab2=true;
        this.tab3=true;
        this.tab4=true;
        this.tab5=false;
        this.paris=document.getElementById('Shrewsbury');
            this.paris.className='active';
       }
       else{

       }
    }

  }
  opennextab(e:any,file:any,v3:any,v4:any,
    v5:any,v6:any,v7:any,v8:any,v9:any,v10:any
    ,v11:any,v12:any,v13:any,v14:any,v15:any,v16:any,v17:any
    ,v18:any,v19:any,v20:any,v21:any,v22:any,v23:any,v24:any,v25:any){
      console.log(

        file,v3,v4,
    v5,v6,v7,v8,v9,v10
    ,v11,v12,v13,v14,v15,v16,v17
    ,v18,v19,v20,v21,v22,v23,v24,v25
      )
      this.storevalue.push(file,);
      console.log(this.storevalue);
           this.t1='London';
           this.t2='Paris';
           this.tab2=false;
           this.tab1=true;
           this.tab3=true;
           this.tab4=true;
           this.paris=document.getElementById('Paris');
           this.paris.className='active';


    }
  opennextab2(e:any){
     if(e=='Tokyo'){
      this.t1='London';
      this.t2='Paris';
      this.t3='Tokyo';
      this.t4='Laguna';
      this.tab1=true;
      this.tab2=true;

      this.tab3=true;
      this.tab4=false;
       this.paris=document.getElementById('paris');
       this.paris.className='active';
    }
  }
  opennextab1(e:any){
   if(e=='Paris'){
      this.t1='London';
      this.t2='Paris';
      this.t3='Tokyo';
      this.tab1=true;
      this.tab2=true;

      this.tab3=false;
      this.tab4=true;
       this.paris=document.getElementById('paris');
       this.paris.className='active';
    }
  }
  opennextab3(e:any){
    if(e=='laguna'){
      console.log('Shrewsbury');
      this.t1='London';
      this.t2='Paris';
      this.t3='Tokyo';
      this.t4='Laguna';
      this.t5='Shrewsbury';
      this.tab1=true;
      this.tab2=true;

      this.tab3=true;
      this.tab4=true;
      this.tab5=false;
       this.paris=document.getElementById('Shrewsbury');
       this.paris.className='active';
     }
   }

   //For Checkbox
   changemenu(event:any){
     console.log(event.target.checked);

   }
   selectmenuimg(event:any){
     console.log(event.target.checked);
   }
   changetopimage(event:any){
    console.log(event.target.checked);
   }
   changesectionimages(event:any){
     console.log(event);
   }
   changesectionurl(event:any){
     console.log(event.target)
   }
   Changelast(event:any){
     console.log(event.target);
   }
   changeMenuURL(event:any){
     console.log(event.target);
   }
   changeeveryday(event:any){
     console.log(event.target.value);
   }
   chnangemonday(event:any){

   }
   changetuesday(event:any){
     console.log(event.target);
   }
   changewednesday(event:any){
     console.log(event.target);
   }
   changethursday(event:any){
     console.log(event.target);
   }
   fridaychange(event:any){
     console.log(event.target);
   }
   saturdaychange(event:any){
     console.log(event.target);
   }
   sundaychange(event:any){
    console.log(event.target);
   }
}
