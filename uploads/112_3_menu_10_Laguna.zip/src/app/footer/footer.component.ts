import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls:['../.././assets/css/apps_inner.css',
             '../.././assets/css/apps.css',
             '../.././assets/css/bootstrap.css' ,
             '../.././assets/css/bootstrap.min.css' ,
              '../.././assets/css/font-awesome.css',
              '../.././assets/css/res.css']
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
