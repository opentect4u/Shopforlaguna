import { getLocaleDateTimeFormat } from '@angular/common';
import { Component, MissingTranslationStrategy, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-comp',
  templateUrl: './comp.component.html',
  styleUrls: ['./comp.component.css']
})
export class CompComponent implements OnInit {
  myDate = new Date();
   greet:any
   min:any;
   sec:any;
   coll:any;
   comma:any;
   com:any[]=[];

  constructor(private router:Router) { }
  class:any;
  Style:any;
  ngOnInit(): void {
    localStorage.setItem('St','2');
    console.log(localStorage.getItem('st'));

    setInterval(()=>{
      var hrs = this.myDate.getHours();
      var minute = this.myDate.getMinutes();
      var second = this.myDate.getSeconds();
    // if (minute < 10) {
    //   this.min = "0" + minute;
    // }
    // if (second < 10) {
    //   this.sec = "0" + second;
    // }

    var prepand = (hrs >= 12)? " PM ":" AM ";

      console.log(hrs+":"+minute+":"+second+""+prepand);
      if (hrs < 12)
          this.greet = 'Good Morning';
      else if (hrs >= 12 && hrs <= 17)
          this.greet = 'Good Afternoon';
      else if (hrs >= 17 && hrs <= 24)
          this.greet = 'Good Evening';
    },1000)

  }
  go_to_mycomponent(){
    this.router.navigate(['/'])
  }

  select_class(sel:any){
    this.class=sel;
    }
    select_style(s:any){
      this.Style=s;
      console.log(s);

    }


    color_text(v:any){
      console.log("color:" +v);
      this.coll=v;
    }

    showval(v:any,v2:any){
       this.comma=v;
       this.com=this.comma.split(',').join("\n");
      //  for(let i=0;i<this.comma.length;i++){
      //   console.log(i+":"+this.com[i]);
      //  }
      console.log(this.com);

    }
}
