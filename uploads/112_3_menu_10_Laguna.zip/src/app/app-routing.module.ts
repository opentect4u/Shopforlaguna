import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MycomComponent } from 'copy/src/app/mycom/mycom.component';

import { CompComponent } from './comp/comp.component';
import { MenuSetupComponent } from './menu-setup/menu-setup.component';

const routes: Routes = [
  {
    path:'',
    component:MenuSetupComponent
  },
    {
  path:'comp',
  component:CompComponent
}]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
