import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-set-up',
  templateUrl: './menu-set-up.component.html',
  styleUrls: ['./menu-set-up.component.css']
})
export class MenuSetUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
