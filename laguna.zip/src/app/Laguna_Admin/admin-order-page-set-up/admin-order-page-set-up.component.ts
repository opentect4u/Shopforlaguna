import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-order-page-set-up',
  templateUrl: './admin-order-page-set-up.component.html',
  styleUrls: ['./admin-order-page-set-up.component.css']
})
export class AdminOrderPageSetUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
