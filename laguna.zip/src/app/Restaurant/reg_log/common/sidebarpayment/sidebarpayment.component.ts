import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebarpayment',
  templateUrl: './sidebarpayment.component.html',
  styleUrls: ['./sidebarpayment.component.css']
})
export class SidebarpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
