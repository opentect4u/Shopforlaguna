export class menuplatform{
    public menu_name:any;
    public name_url:any;
    public image:any;
}