export class url_set{
    static api_url="http://localhost:3000";
  // static api_url="https://lagunaapi.shoplocal-lagunabeach.com";
  // static Redirect_url="https://shoplocal-lagunabeach.com/#/menu/";
  static Redirect_url="http://localhost:4200/#/menu/";
    static Api_url="http://localhost:4200";
  // static Api_url="https://shoplocal-lagunabeach.com";
}