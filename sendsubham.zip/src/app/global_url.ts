export class global_url_test{
  // static URL="http://localhost:3000/";
  static URL="https://lagunaapi.shoplocal-lagunabeach.com";

  
}