export class url_set{
    // static api_url="http://localhost:3000";
  static api_url="https://lagunaapi.shoplocal-lagunabeach.com";


}